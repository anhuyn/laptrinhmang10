package Models;

import java.io.PrintWriter;
import java.net.Socket;

public class ClientSocket {
    public Socket socket;
    public PrintWriter writer;
}
