package Models;
// Ngoc Anh 1504
public abstract class Client {
    public static int currentID = 0;
    // Ngoc Anh 1504
    public int idClient;
    public String nameClient;
    // Ngoc Anh 1504
    public Room room;
}
